# DevConnect / ConectaPlus — Parte do Daniel (Sprint 2)

Este pacote contém apenas os módulos desenvolvidos pelo Daniel no Sprint 2, mais
o necessário (db.json e configuração do json-server) para rodar e testar as telas.

## Módulos incluídos

- `codigo/public/modulos/home-page` — Página inicial com os cards das campanhas
  (vaquinhas), incluindo o botão "Saiba mais"
- `codigo/public/modulos/vaquinha` — Criação de vaquinha (`criar-vaquinha`) e
  página de detalhes da vaquinha (`detalhes-vaquinha`, aberta pelo "Saiba mais")
- `codigo/public/modulos/detalhes-ong` — Página de detalhes da ONG, com as
  emergências e barra de progresso

## Como rodar

1. Entrar na pasta `codigo`
2. Instalar as dependências:
   ```
   npm install
   ```
3. Iniciar o servidor (json-server na porta 3000):
   ```
   npm start
   ```
4. Abrir o arquivo `codigo/public/modulos/home-page/home_page.html` no navegador

## Fluxo de teste

1. Na home, veja os cards das vaquinhas cadastradas
2. Clique em "Saiba mais" para ver todos os detalhes da vaquinha
3. Se a vaquinha tiver uma ONG vinculada, clique em "Ver ONG responsável"
4. Volte para a home e clique em "+ Criar Vaquinha" para cadastrar uma nova
   campanha — ela aparecerá automaticamente como card na home
